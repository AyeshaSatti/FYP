const express = require('express')
const mongoose = require ('mongoose');
const Joi = require ('joi');
const router = express.Router();



const InstituteDetails = mongoose.model('InstituteDetails', new mongoose.Schema({
    name: String,
    email: String,
    phone: {
        type : String,
        required : true,
        minlength : 5,
        maxlength : 10
    },
    password: {
        type : String,
        required : true,
        minlength : 5,
        maxlength : 10
    },
    aboutUs :{
        type : String,
        required : true,
        minlength : 5,
        maxlength : 250
    },

    date: {type : Date, default: Date.now}

})
);




router.get('/', async(req, res) => {
const instituteDetails = await InstituteDetails.find()
res.send(instituteDetails);
});


router.post('/', async(req, res)=>{
    
    
    let instituteDetails = new InstituteDetails(
        {
            name : req.body.name,
            email : req.body.email, 
            phone : req.body.phone,
            password :  req.body.password,
            aboutUs : req.body.aboutUs

            
        });
        instituteDetails = await instituteDetails.save();
        res.send(instituteDetails);
    });


// function validateUser (InstituteDetails)
// {
//     const schema = {  name : Joi.string().min(25).required(),
//         email : Joi.string().min(25).required(),
//         phone : Joi.string().min(15).required(), 
//         password : Joi.string().min(25).required(),
//         aboutUs : Joi.string().min(250).required(),
//     };
//  return Joi.validate(user, schema);
// };

module.exports = router;