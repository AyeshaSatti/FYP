const express = require('express')
const mongoose = require ('mongoose');
const Joi = require ('joi');
const router = express.Router();



const User = mongoose.model('Users', new mongoose.Schema({
    name: String,
    email: String,
    phone: {
        type : String,
        required : true,
        minlength : 5,
        maxlength : 10
    },
    password: {
        type : String,
        required : true,
        minlength : 5,
        maxlength : 10
    },
    confPassword :{
        type : String,
        required : true,
        minlength : 5,
        maxlength : 10
    },

    date: {type : Date, default: Date.now}

})
);




router.get('/', async(req, res) => {
const users = await User.find()
res.send(users);
});



function validateUser (User)
{
    const schema = {  name : Joi.string().min(25).required(),
        email : Joi.string().min(25).required(),
        phone : Joi.string().min(15).required(), 
        password : Joi.string().min(25).required(),
        confPassword : Joi.string().min(25).required(),
    };
 return Joi.validate(user, schema);
};

module.exports = router;