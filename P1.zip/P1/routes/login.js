const express = require('express')
const mongoose = require ('mongoose');
const Joi = require ('joi');
const router = express.Router();



const LoginUsers = mongoose.model('LoginUsers', new mongoose.Schema({
    
    email: String,
    
    password: {
        type : String,
        required : true,
        minlength : 5,
        maxlength : 10
    },
    date: {type : Date, default: Date.now}

})
);




router.get('/', async(req, res) => {
const users = await User.find()
res.send(users);
});


router.post('/', async(req, res)=>{
    
    
let loginUsers = new LoginUsers(
    {
        email : req.body.email, 
        password :  req.body.password,
        
    });
    loginUsers = await loginUsers.save();
    res.send(loginUsers);
});


module.exports = router;