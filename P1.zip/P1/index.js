const express = require('express')
const mongoose = require ('mongoose');
const signUp = require('./routes/signUp')
const login = require('./routes/login')
const instituteDetails = require('./routes/instituteDetails')
//const videoStreaming = require('./routes/videoStreaming')
const Joi = require ('joi');
const app = express();




mongoose.connect('mongodb://localhost/Users')
 .then(()=> console.log ("Mongo DB is connected Successfully ..."))
 .catch(err => console.log("Error in Connection..."))


app.use(express.json());
app.use('/api/signUp', signUp);
app.use('/api/login', login);
//app.use('/api/videoStreaming', videoStreaming);
app.use('/api/instituteDetails', instituteDetails);

    

// app.delete('/:id',async (req, res) => {
    
//     const person = await User.findOneAndRemove(req.param.id);
//     if (!person) res.status(404).send ('User with this ID is not found')


//     res.send(person);
// });



// app.put('/:id', async(req, res)=>{
 
//     // const {error} = validateUser (req.body); // obj destructor, validcourse will do when it is valid, else this destructor will do if not valid
//     // if (error)
//     // {
//     //     res.status(400).send(error.details[0].message);
//     //     return;
//     // };

//     const person = await User.findOneAndUpdate(req.param.id,
//         {
//             name : req.body.name,
//             email : req.body.email, 
//             phone : req.body.phone,
//             password :  req.body.password,
            
//         }, {new: true});
//     if (!person) res.status(404).send ('User with this ID is not found');

//     res.send(person);

// })






const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Listening to the port ${port}`))

